package com.example.demo;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service
public class QuestionService {

    private static final Logger logger = LoggerFactory.getLogger(QuestionService.class);
    private static final String IMAGE_DIRECTORY = "C:\\E-commerce\\"; // Ensure the trailing slash

    @Autowired
    private QuestionRepository questionRepository;

    @Autowired
    private CollegeRepository collegeRepository;

    public void saveQuestion(QuestionRequestDTO questionDTO, Long collegeId) throws IOException {
        Question question = new Question();

        // Retrieve the College object using collegeId
        College college = collegeRepository.findById(collegeId)
            .orElseThrow(() -> new RuntimeException("College not found with id: " + collegeId));

        // Set question content as text or image path
        question.setQuestionContent(handleTextOrImage(questionDTO.getQuestionContent(), "question"));

        // Set options A, B, C, and D as text or image path with specific prefixes
        question.setOptionA(handleTextOrImage(questionDTO.getOptionA(), "optionA"));
        question.setOptionB(handleTextOrImage(questionDTO.getOptionB(), "optionB"));
        question.setOptionC(handleTextOrImage(questionDTO.getOptionC(), "optionC"));
        question.setOptionD(handleTextOrImage(questionDTO.getOptionD(), "optionD"));

        // Handle correct answer as text or image path with a correct answer prefix
        question.setCorrectAnswer(handleTextOrImage(questionDTO.getCorrectAnswer(), "correctAnswer"));

        // Set topic
        question.setTopic(questionDTO.getTopic());

        // Set additional fields
        question.setCollege(college);

        // Save question to database
        questionRepository.save(question);
        logger.info("Saved question for college ID: {}", collegeId);
    }

    private String handleTextOrImage(Object input, String prefix) throws IOException {
        if (input instanceof MultipartFile) {
            MultipartFile file = (MultipartFile) input;

            // File type validation
            if (!isValidImage(file)) {
                throw new IOException("Invalid file type for " + file.getOriginalFilename());
            }

            String originalFilename = file.getOriginalFilename();
            String prefixedFilename = prefix + "_" + originalFilename; // Prefix the original filename
            Path filePath = Paths.get(IMAGE_DIRECTORY, prefixedFilename);

            // Handle filename collisions
            int count = 1;
            while (Files.exists(filePath)) {
                prefixedFilename = prefix + "_" + count + "_" + originalFilename; // Generate new filename
                filePath = Paths.get(IMAGE_DIRECTORY, prefixedFilename);
                count++;
            }

            // Ensure the image directory exists
            Files.createDirectories(filePath.getParent());

            // Store file on disk
            Files.write(filePath, file.getBytes());

            // Return the relative path for serving images in the web application
            logger.info("Saving image to: {}", filePath.toString()); // Log the saving path
            return "/images/" + prefixedFilename; // Adjust according to your web configuration
        } else if (input instanceof String) {
            return (String) input;
        }
        return null;
    }

    private boolean isValidImage(MultipartFile file) {
        String contentType = file.getContentType();
        return contentType != null && (contentType.startsWith("image/")); // Basic image check
    }
}

 